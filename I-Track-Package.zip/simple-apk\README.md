# I-Track Mobile App 
 
This is your I-Track mobile application package. 
 
## Installation Options: 
 
### Option 1: Web App (Recommended) 
1. Deploy the web-build folder to any web server 
2. Access via browser on mobile device 
3. Use "Add to Home Screen" for app-like experience 
 
### Option 2: Development Mode 
1. Install Expo Go app on your phone 
2. Run: npx expo start 
3. Scan QR code with Expo Go 
 
## Backend Configuration 
- Production: https://itrack-backend-1.onrender.com 
- The app will automatically connect to the working backend 
